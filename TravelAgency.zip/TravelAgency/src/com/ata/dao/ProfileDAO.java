package com.ata.dao;

import java.sql.SQLException;

import com.ata.bean.ProfileBean;


public interface ProfileDAO {
	
	/**
	 * @param profileBean Function Parameter
	 * @return String
	 * @throws SQLException Throws any SQL Exception
	 */
	String register(ProfileBean profileBean) throws SQLException;
	 
	 /**
	 * @param userId Function Parameter
	 * @return ProfileBean
	 * @throws SQLException Throws any SQL Exception
	 */
	ProfileBean findByID(String userId) throws SQLException;

}
