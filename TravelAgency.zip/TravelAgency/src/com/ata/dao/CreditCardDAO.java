package com.ata.dao;

import java.sql.SQLException;

import com.ata.bean.CreditCardBean;


public interface CreditCardDAO 
{
	 /**
	 * @param creditCardBean Function Parameter
	 * @return String
	 * @throws SQLException Throws any SQL Exception
	 */
	String createCreditCard(CreditCardBean creditCardBean) throws SQLException;
}
