
package com.ata.bean;


public class CredentialsBean {
	public String getQus() {
		return qus;
	}

	public void setQus(String qus) {
		this.qus = qus;
	}

	public String getAns() {
		return ans;
	}

	public void setAns(String ans) {
		this.ans = ans;
	}

	private String userID;
	private String password;
	private String userType;
	private int loginStatus;
	private String qus;
	private String ans;

	
	public String getUserID() 
	{
		return userID;
	}
	
	
	public void setUserID(String userID) 
	{
		this.userID = userID;
	}
	
	
	public String getPassword() 
	{
		return password;
	}
	
	
	public void setPassword(String password) 
	{
		this.password = password;
	}
	
	
	public String getUserType() 
	{
		return userType;
	}
	
	
	public void setUserType(String userType) 
	{
		this.userType = userType;
	}
	
	
	public int getLoginStatus() 
	{
		return loginStatus;
	}
	
	
	public void setLoginStatus(int loginStatus) 
	{
		this.loginStatus = loginStatus;
	}
}
