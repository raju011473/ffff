package com.ata.bean;



public class RouteBean 
{
private String routeID;
private String source;
private String destination;
private double distance;
private double travelDuration;

/** 
 * @return routeID
 */
public String getRouteID() {
	return routeID;
}

/**
 * @param routeID Sets RouteID
 */
public void setRouteID(String routeID) {
	this.routeID = routeID;
}

/**
 * @return source
 */
public String getSource() {
	return source;
}

/**
 * @param source Sets Source
 */
public void setSource(String source) {
	this.source = source;
}

/**
 * @return destination
 */
public String getDestination() {
	return destination;
}

/**
 * @param destination Sets Destination
 */
public void setDestination(String destination) {
	this.destination = destination;
}

/**
 * @return distance
 */
public double getDistance() {
	return distance;
}

/**
 * @param distance Sets Distance
 */
public void setDistance(double distance) {
	this.distance = distance;
}

/**
 * @return travelDuration
 */
public double getTravelDuration() {
	return travelDuration;
}

/**
 * @param travelDuration Sets Travel Duration
 */
public void setTravelDuration(double travelDuration) {
	this.travelDuration = travelDuration;
}


}
